"""La classe enemy et les fonctions qui la compose"""
import pygame


# Enemy class
class Enemy(pygame.sprite.Sprite): #pylint: disable=too-few-public-methods
    """
    Class enemy qui correspond au avion enemy
    """
    def __init__(self, enemy_img,
            enemy_down_imgs,
            init_pos, speed):
        pygame.sprite.Sprite.__init__(self)
        self.image = enemy_img
        self.rect = self.image.get_rect()
        self.rect.topleft = init_pos
        self.down_imgs = enemy_down_imgs
        self.speed = speed
        self.down_index = 0

    def move (self):
        """
        La fonction move() déplace l'enemie vers le bas de l'écran en ajoutant la vitesse à la
        coordonnée y de la enemie
        """
        self.rect.top += self.speed
