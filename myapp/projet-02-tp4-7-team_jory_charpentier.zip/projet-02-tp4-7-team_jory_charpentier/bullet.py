"""
[Ce bloc est la documentation du module]
Un bullet.
Ce code est basee sur le code de Sébastien CHAZALLET,
auteur du livre "Python 3, les fondamentaux du language"
"""

import pygame

# Bullets
class Bullet (pygame.sprite.Sprite): #pylint: disable=too-few-public-methods
    """
    Cette classe represente un bullet
    """
    def __init__(self, bullet_img, init_pos):
        pygame.sprite.Sprite.__init__(self)
        self.image = bullet_img
        self.rect = self.image.get_rect()
        self.rect.midbottom = init_pos
        self.speed = 10

    def move (self):
        """
        Fait avancer un bullet
        """
        self.rect.top -= self.speed
