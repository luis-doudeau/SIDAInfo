# -*- coding: utf-8 -*-
"""
    Il dessine l'arrière-plan, le joueur, les ennemis, les balles et les explosions
    et fais fonctionné le jeu

    On affiche le score a la fin
"""
#pylint: disable=invalid-name
#pylint: disable=no-member
#pylint: disable=redefined-outer-name

import random
import sys
import pygame
import pygame.locals
import enemy
import player as joueur
import constante
import asyncio




# Initialize the game
pygame.init()
screen = pygame.display.set_mode((constante.SCREEN_WIDTH, constante.SCREEN_HEIGHT))
pygame.display.set_caption('SexInfo : The Game')
# Load the background map
background = pygame.image.load('resources/image/background.png')

# Load the picture of the plane
plane_img = pygame.image.load('resources/image/shoot.png') ########

def init_destruction_enemis():
    # destruction des ennemis
    enemy1_down_sound = pygame.mixer.Sound('resources/sound/enemy1_down.wav')
    enemy1_down_sound.set_volume(0.3)
    enemy1_down_imgs = []
    # Select the position of the plane in the big picture, generate subsurface,
    #  and then initialize the position of the plane.
    enemy1_down_imgs.append(plane_img.subsurface(pygame.Rect(267, 347, 57, 43)))
    enemy1_down_imgs.append(plane_img.subsurface(pygame.Rect(873, 697, 57, 43)))
    enemy1_down_imgs.append(plane_img.subsurface(pygame.Rect(267, 296, 57, 43)))
    enemy1_down_imgs.append(plane_img.subsurface(pygame.Rect(930, 697, 57, 43)))
    # Stockez des avions détruits pour le rendu d'animations de sprites d'épaves
    enemies_down = pygame.sprite.Group()
    return enemy1_down_sound, enemy1_down_imgs, enemies_down




def init_joueur():
    # Définir les paramètres liés au joueur
    plane = pygame.image.load('resources/image/penis.png')
    player_rect = []
    player_rect.append(pygame.Rect(0, 0, 90, 90))
    # Zone d'image du sprite du joueur
    player_rect.append(pygame.Rect(0, 0, 90, 90))
    player_rect.append(pygame.Rect(0, 0, 90, 90))
    # Zone d'image du sprite d'explosion du joueur
    player_rect.append(pygame.Rect(0, 0, 90, 90))
    player_rect.append(pygame.Rect(0, 0, 90, 90))
    player_rect.append(pygame.Rect(0, 0, 90, 90))
    player_pos = [200, 600]
    player = joueur.Player(plane, player_rect, player_pos)
    return player


def init_bullet():
    bullet_sound = pygame.mixer.Sound('resources/sound/bullet.wav')
    bullet_sound.set_volume(0.3)
    # Définir les paramètres liés à la surface utilisés par l'objet puce (bullets)
    bullet_rect = pygame.Rect(constante.TAILLE_SURFACE_BULLET)
    bullet_img = pygame.image.load('resources/image/tache.png')
    shoot_frequency = 0
    return bullet_sound, bullet_rect, bullet_img, shoot_frequency
    

def init_surface_enemie():
    # Définir les paramètres liés à la surface utilisés par l'objet avion ennemi
    enemy1_rect = pygame.Rect(constante.TAILLE_SURFACE_ENEMIE)
    enemy1_img = pygame.image.load('resources/image/vih.png') ###############################
    enemies1 = pygame.sprite.Group()
    enemy_frequency = 0
    return enemy1_rect, enemy1_img, enemies1, enemy_frequency


def init_game_over():
    #Game Over
    player_down_index = 16
    game_over = pygame.image.load('resources/image/gameover.png')
    game_over_sound = pygame.mixer.Sound('resources/sound/game_over.wav')
    game_over_sound.set_volume(0.3)
    return player_down_index, game_over, game_over_sound

def init_backgound_deroulant():
    backgound_y = 0
    backgound_y2 = background.get_height()*-1
    return backgound_y, backgound_y2

def init_score():
    score = 0
    return score

#Initialisation des sons, imgs et liste des enemies detruits
enemy1_down_sound, enemy1_down_imgs, enemies_down = init_destruction_enemis()

#Initialisation du joueur
player = init_joueur()

#Initialisation des bullets
bullet_sound, bullet_rect, bullet_img, shoot_frequency = init_bullet()

#Initialisation des surfaces enemie
enemy1_rect, enemy1_img, enemies1, enemy_frequency = init_surface_enemie()

#Initialisation du game over
player_down_index, game_over, game_over_sound = init_game_over()

#Initialisation des valeurs pour le backgound deroulant
backgound_y, backgound_y2 = init_backgound_deroulant()

#Initialisation du score
score = init_score()

base_speed_enemy = constante.BASE_SPEED_ENEMY
frequence_tir = constante.FREQUENCE_TIR
frequence_apparition_enemy = constante.FREQUENCE_APPARITION_ENEMY

clock = pygame.time.Clock()
running = True



def redraw_window(backgound_y, backgound_y2, score_text, text_rect):
    screen.blit(background, (0, backgound_y))  # draws our first bg image
    screen.blit(background, (0, backgound_y2))  # draws the seconf bg image
    screen.blit(score_text, text_rect)

def faire_apparaitre_avion_enemy(enemy_frequency, base_speed_enemy, frequence_apparition_enemy):
    """
    Il crée un nouvel ennemi toutes les 50 images et réinitialise le compteur toutes les 100 images

    :param enemy_frequency: La fréquence d'apparition d'avions ennemis
    """
    # Faire apparaître des avions ennemis :
    if enemy_frequency % frequence_apparition_enemy == 0:
        enemy1_pos = [random.randint(0, constante.SCREEN_WIDTH - enemy1_rect.width), 0]
        enemy1 = enemy.Enemy(enemy1_img,
                enemy1_down_imgs,
                enemy1_pos, base_speed_enemy)
        enemies1.add(enemy1)
    enemy_frequency += 1
    if enemy_frequency >= frequence_apparition_enemy*2:
        enemy_frequency = 0
    return enemy_frequency

def deplacer_avion_enemy():
    """
    La fonction déplace l'avion ennemi, s'il dépasse la portée de la fenêtre, supprimez-le

    :param enemies1: Le groupe d'avions ennemis
    """
    # Déplacez l'avion ennemi, s'il dépasse la plage de la fenêtre, supprimez-le
    for un_enemy in enemies1:
        un_enemy.move()
        # Déterminez si le joueur a été touché
        if pygame.sprite.collide_circle(un_enemy, player):
            enemies_down.add(un_enemy)
            enemies1.remove(un_enemy)
            player.is_hit = True
            game_over_sound.play()
            break
        if un_enemy.rect.top > constante.SCREEN_HEIGHT:
            enemies1.remove(un_enemy)
            player.is_hit = True
            game_over_sound.play()

    # Ajoutez l'objet avion ennemi touché au groupe d'avions ennemis détruits
    enemies1_down = pygame.sprite.groupcollide(enemies1, player.bullets, 1, 1)
    for enemy_down in enemies1_down:
        enemies_down.add(enemy_down)

def controle_frequence_tir(shoot_frequency, frequence_tir):
    """
    Si la fréquence de tir est divisible par 15, jouez le son de balle et tirez une balle, puis
    incrémentez la fréquence de tir de 1. Si la fréquence de tir est supérieure ou égale à 15,
    remettez-la à 0.

    :param shoot_frequency: C'est le nombre d'images qui se sont écoulées depuis que
    la dernière balle a été tirée
    """
    # Contrôler la fréquence des tirs de balles et des balles de feu
    if shoot_frequency % frequence_tir == 0:
        bullet_sound.play()
        player.shoot(bullet_img)
    shoot_frequency += 1
    if shoot_frequency >= frequence_tir:
        shoot_frequency = 0
    return shoot_frequency, frequence_tir


def deplacer_puce():
    """
    Il déplace les balles et les supprime si elles sortent de l'écran
    """
    # Déplacer la puce, la supprimer si elle dépasse le cadre de la fenêtre
    for bullet in player.bullets:
        bullet.move()
        if bullet.rect.bottom < 0:
            player.bullets.remove(bullet)

def draw_enemie_exlosion(score):
    """
    Il prend un score comme argument, parcourt la liste des ennemis_vers le bas,
    joue un son si l'ennemi
    est à la première image de l'animation d'explosion, supprime l'ennemi de la liste s'il est à la
    dernière image de l'animation d'explosion, et augmente le score par une valeur constante

    :param score: Le score actuel du joueur
    :return: Le score est rendu.
    """
    for enemy_down in enemies_down:
        if enemy_down.down_index == 0:
            enemy1_down_sound.play()
        if enemy_down.down_index > 7:
            enemies_down.remove(enemy_down)
            score += constante.POINT_KILL
            continue
        screen.blit(enemy_down.down_imgs[enemy_down.down_index // 2], enemy_down.rect)
        enemy_down.down_index += 1
    return score

def bouger_backgound(backgound_y, backgound_y2):
    backgound_y += constante.SPEED_BACKGOUND  # Move both background images back
    backgound_y2 += constante.SPEED_BACKGOUND

    if backgound_y > background.get_height():  # If our bg is at the -width then reset its position
        backgound_y = background.get_height()*-1
    
    if backgound_y2 > background.get_height():
        backgound_y2 = background.get_height()*-1
    return backgound_y,backgound_y2

def affiche_score():
    score_font = pygame.font.Font(None, constante.TAILLE_POLICE_SCORE)
    score_text = score_font.render(str(score), True, constante.COULEUR_GRIS)
    text_rect = score_text.get_rect()
    text_rect.topleft = [10, 10]
    return score_text, text_rect

def dessiner_avion_enemie(running, shoot_frequency, player_down_index):
    # dessiner l'avion du joueur
    if not player.is_hit:
        screen.blit(player.image[player.img_index], player.rect)
        # Changer l'index de l'image pour animer l'avion
        player.img_index = shoot_frequency // 8
    else:
        player.img_index = player_down_index // 8
        screen.blit(player.image[player.img_index], player.rect)
        player_down_index += 1
        if player_down_index > 47:
            running = False
    return running, player_down_index

def ajout_avion_enemie_au_groupe():
    enemies1_down = pygame.sprite.groupcollide(enemies1, player.bullets, 1, 1)
    for enemy_down in enemies1_down:
        enemies_down.add(enemy_down)

def deplacer_joueur():
    # Monitor keyboard events
    key_pressed = pygame.key.get_pressed()
    if key_pressed[pygame.locals.K_w] or key_pressed[pygame.locals.K_UP]:
        player.move_up()
    if key_pressed[pygame.locals.K_s] or key_pressed[pygame.locals.K_DOWN]:
        player.move_down()
    if key_pressed[pygame.locals.K_a] or key_pressed[pygame.locals.K_LEFT]:
        player.move_left()
    if key_pressed[pygame.locals.K_d] or key_pressed[pygame.locals.K_RIGHT]:
        player.move_right()

def affichage_game_over():
    font = pygame.font.Font(None, constante.TAILLE_POLICE_GAME_OVER)
    text = font.render('Score: '+ str(score), True, constante.COULEUR_ROUGE)
    text_rect = text.get_rect()
    text_rect.centerx = screen.get_rect().centerx
    text_rect.centery = screen.get_rect().centery + 24
    screen.blit(game_over, (0, 0))

def changement_niveau(score, base_speed_enemy, frequence_tir, frequence_apparition_enemy):
    if player.speed < 18:
        player.speed += 0.005
    if base_speed_enemy <15:
        base_speed_enemy += 0.0025
    if frequence_tir > 5:
        frequence_tir -= 0.0015
    if frequence_apparition_enemy >0:
        frequence_apparition_enemy -= 0.01
    return score, base_speed_enemy, frequence_tir, frequence_apparition_enemy


def quitter():
    # Process game exits
    for event in pygame.event.get():
        if event.type == pygame.QUIT:
            pygame.quit()
            sys.exit()

while running:
    # Contrôlez la fréquence d'images maximale du jeu
    clock.tick(45)



    # Draw the background
    screen.fill (0)

    score_text, text_rect = affiche_score()


    backgound_y,backgound_y2 = bouger_backgound(backgound_y, backgound_y2)
    redraw_window(backgound_y, backgound_y2, score_text, text_rect)

    shoot_frequency, frequence_tir = controle_frequence_tir(shoot_frequency, frequence_tir)

    deplacer_puce()

    # Draw an airplane
    # screen.blit (player, player_pos)
    
    running, player_down_index = dessiner_avion_enemie(running,  shoot_frequency, player_down_index)

    player.bullets.draw(screen)

    enemy_frequency = faire_apparaitre_avion_enemy(enemy_frequency, base_speed_enemy, frequence_apparition_enemy)
    deplacer_avion_enemy()
    enemies1.draw(screen)
    # Ajoutez l'objet avion ennemi touché au groupe d'avions ennemis détruits.
    ajout_avion_enemie_au_groupe()
    score = draw_enemie_exlosion(score)
    score,base_speed_enemy, frequence_tir, frequence_apparition_enemy = changement_niveau(score,base_speed_enemy, frequence_tir, frequence_apparition_enemy)
    # Update the screen
    pygame.display.update()
    deplacer_joueur()
    quitter()
affichage_game_over()     

    
while 1:
# Process game exits
    for event in pygame.event.get():
        if event.type == pygame.QUIT:
            pygame.quit()
            sys.exit()
    pygame.display.update()


