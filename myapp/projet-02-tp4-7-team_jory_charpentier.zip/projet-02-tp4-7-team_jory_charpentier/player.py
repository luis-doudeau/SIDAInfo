"""La classe de joueur est utilisée pour créer un objet joueur,
 qui est utilisé pour contrôler l'avion du joueur.
"""
import pygame
import constante
import bullet as balle

# Players
class Player (pygame.sprite.Sprite):
    """
    Class qui represente le joueure
    """
    def __init__(self, plane_img, player_rect, init_pos):
        pygame.sprite.Sprite.__init__(self)
        self.image = [] # List of pictures of player object wizard

        for _,value in enumerate(player_rect):
            self.image.append(plane_img.subsurface(value).convert_alpha())

        self.rect = player_rect[0] # Initialize the rectangle where the picture is located
        self.rect.topleft = init_pos # Initialize the upper left corner coordinates of the rectangle
        self.bullets = pygame.sprite.Group() # Collection of bullets fired by the player's aircraft
        self.speed = constante.BASE_SPEED # Initialize the player speed, here is a definite value.
        self.img_index = 0 # Player Wizard Image Index
        self.is_hit = False

    def move_up (self):
        """
        Si le joueur est au bord de l'ecran en haut ne fait rien.
        Sinon deplace le joueur vers le haut.
        """
        if self.rect.top <= 0:
            self.rect.top = 0
        else:
            self.rect.top -= self.speed

    def move_down(self):
        """
        Si le joueur est au bord de l'ecran en bas ne fait rien.
        Sinon deplace le joueur vers le bas.
        """
        if self.rect.top >= constante.SCREEN_HEIGHT - self.rect.height:
            self.rect.top = constante.SCREEN_HEIGHT - self.rect.height
        else:
            self.rect.top += self.speed

    def move_left(self):
        """
        Si le joueur est au bord de l'ecran a gauche ne fait rien.
        Sinon deplace le joueur vers la gauche.
        """
        if self.rect.left <= 0:
            self.rect.left = 0
        else:
            self.rect.left -= self.speed

    def move_right(self):
        """
        Si le joueur est au bord de l'ecran a droite ne fait rien.
        Sinon deplace le joueur vers la droite.
        """
        if self.rect.left >= constante.SCREEN_WIDTH - self.rect.width:
            self.rect.left = constante.SCREEN_WIDTH - self.rect.width
        else:
            self.rect.left += self.speed

    def shoot (self, bullet_img):
        """
        Il crée un objet puce et l'ajoute a la liste de puces

        :param bullet_img: L'image de la balle
        """
        bullet = balle.Bullet(bullet_img, self.rect.midtop)
        self.bullets.add(bullet)
