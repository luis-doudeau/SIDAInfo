# projet-02-tp4-7-team_jory_charpentier
projet-02-tp4-7-team_jory_charpentier created by GitHub Classroom

## Développeur1 
Charpentier Maxym
## Développeur2 
Jory Jonathan

# Titre du projet : Tetris

## Une petite description du projet
Le projet consiste à ameliorer le code d'un tetris déjà existant afin de répondre à toutes les normes actuelles. 


## Pré-requis

Pygame



## Installation

Executez la commande pip install pygame


## Démarrage

Executez simplement le fichier tetris avec la commande python3 tetris.py

## Comment jouer ?
- Fleche du haut : changer l'orientation de la pièce
- Fleche du bas : Fait descendre la pièce plus vite
- Fleche de gauche : Deplace la pièce vers la gauche
- Fleche de droite : Deplace la pièce vers la droite
- Espace : Fait descendre la pièce instantanément tout en bas
- P : Met le jeu en pause ( Appuyer sur n'importe quelle touche pour enlever la pause )

## Versions

Premiere version 1.0 : https://github.com/BUT-info-IUT-d-Orleans/projet-01-tp1-3-MaxymCh/tags

## Auteurs

Charpentier Maxym


## License

Ce projet est sous licence exemple: GPL - voir le fichier LICENSE pour plus d'information


## YapF 

YapF a formatter le code. Il a enlever les espaces ainsi que les sauts de lignes inutiles. Il a ajouter des espaces et des retours à la ligne quand cela était nécessaire. Il sert a rendre le code plus lisible e à respecter les bonnes pratiques en python.
